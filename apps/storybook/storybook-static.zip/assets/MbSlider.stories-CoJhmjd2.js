import{r as o,w as i}from"./vue.esm-bundler-BvEW-W-m.js";import{_ as s}from"./MbSlider.vue_vue_type_script_setup_true_lang-VpmUtr5p.js";const M=["default","hover","focus","pressed","disabled"],h={title:"Components/MbSlider",component:s,tags:["autodocs"],args:{modelValue:70,rangeStart:null,min:0,max:100,step:1,state:"default",label:"Label",showTicks:!0,showValueLabels:!0,disabled:!1,hint:""},argTypes:{state:{control:"inline-radio",options:M}},render:e=>({components:{MbSlider:s},setup(){const d=o(Number(e.modelValue??0)),n=o(e.rangeStart??null);return i(()=>e.modelValue,r=>{d.value=Number(r??0)}),i(()=>e.rangeStart,r=>{n.value=r??null}),{args:e,end:d,start:n}},template:`
      <div style="display:grid;gap:20px;align-items:start;justify-items:start;padding:24px;">
        <MbSlider
          v-bind="args"
          :model-value="end"
          :range-start="start"
          @update:modelValue="end = $event"
          @update:rangeStart="start = $event"
        />
      </div>
    `})},a={},t={args:{label:"Price range",rangeStart:35,modelValue:80}},l={render:()=>({components:{MbSlider:s},template:`
      <div style="display:grid;gap:24px;padding:24px;">
        <MbSlider label="Default" :model-value="70" state="default" />
        <MbSlider label="Hover" :model-value="70" state="hover" />
        <MbSlider label="Focus" :model-value="70" state="focus" />
        <MbSlider label="Pressed" :model-value="70" state="pressed" />
        <MbSlider label="Disabled" :model-value="70" state="disabled" :disabled="true" />
        <MbSlider label="Range" :range-start="25" :model-value="75" state="default" />
      </div>
    `})};var u,m,p;a.parameters={...a.parameters,docs:{...(u=a.parameters)==null?void 0:u.docs,source:{originalSource:"{}",...(p=(m=a.parameters)==null?void 0:m.docs)==null?void 0:p.source}}};var b,c,g;t.parameters={...t.parameters,docs:{...(b=t.parameters)==null?void 0:b.docs,source:{originalSource:`{
  args: {
    label: 'Price range',
    rangeStart: 35,
    modelValue: 80
  }
}`,...(g=(c=t.parameters)==null?void 0:c.docs)==null?void 0:g.source}}};var v,S,f;l.parameters={...l.parameters,docs:{...(v=l.parameters)==null?void 0:v.docs,source:{originalSource:`{
  render: () => ({
    components: {
      MbSlider
    },
    template: \`
      <div style="display:grid;gap:24px;padding:24px;">
        <MbSlider label="Default" :model-value="70" state="default" />
        <MbSlider label="Hover" :model-value="70" state="hover" />
        <MbSlider label="Focus" :model-value="70" state="focus" />
        <MbSlider label="Pressed" :model-value="70" state="pressed" />
        <MbSlider label="Disabled" :model-value="70" state="disabled" :disabled="true" />
        <MbSlider label="Range" :range-start="25" :model-value="75" state="default" />
      </div>
    \`
  })
}`,...(f=(S=l.parameters)==null?void 0:S.docs)==null?void 0:f.source}}};const V=["Playground","Range","States"];export{a as Playground,t as Range,l as States,V as __namedExportsOrder,h as default};
