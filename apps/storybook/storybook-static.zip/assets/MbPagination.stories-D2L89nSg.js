import{v as i}from"./visual-meta-DVsEdd8r.js";const o={title:"Visual/MbPagination",tags:["autodocs"],render:r=>({setup(){return{args:r}},template:`<section
        data-visual-target
        data-component="MbPagination"
        style="
          width: 100%;
          min-height: 280px;
          border-radius: 12px;
          border: 1px solid #c1c8cd;
          padding: 24px;
          background: var(--mb-surface, #ffffff);
          color: var(--mb-text, #11181c);
          font-family: Inter, sans-serif;
        "
      >
        <h2 style="margin: 0 0 12px; font-size: 20px; line-height: 28px;">MbPagination</h2>
        <p style="margin: 0; font-size: 14px; line-height: 20px;">{{ args.label }}</p>
      </section>`}),args:{label:"MbPagination matrix placeholder. Replace with real component implementation."}},a={parameters:i({figmaNodeId:"1161:70892",viewport:"desktop",theme:"light",state:"matrix",variant:"all"})};var e,t,n;a.parameters={...a.parameters,docs:{...(e=a.parameters)==null?void 0:e.docs,source:{originalSource:`{
  parameters: visualParameters({
    figmaNodeId: '1161:70892',
    viewport: 'desktop',
    theme: 'light',
    state: 'matrix',
    variant: 'all'
  })
}`,...(n=(t=a.parameters)==null?void 0:t.docs)==null?void 0:n.source}}};const p=["Matrix"];export{a as Matrix,p as __namedExportsOrder,o as default};
