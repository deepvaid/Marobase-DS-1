import{r as h,w as b}from"./vue.esm-bundler-BvEW-W-m.js";import{_ as s}from"./MbInputField.vue_vue_type_script_setup_true_lang-CO75S3gS.js";const x=["default","hover","focus","disabled","error"],F={title:"Components/MbTextField",component:s,tags:["autodocs"],parameters:{docs:{description:{component:"Compatibility alias for MbInputField while links migrate."}}},args:{modelValue:"",state:"default",label:"Label",required:!1,hint:"Hint text",errorMessage:"Error message",placeholder:"Placeholder",leftAddon:"Text",trailingIcon:"rhombus",width:320},argTypes:{state:{control:"inline-radio",options:x},trailingIcon:{control:"inline-radio",options:["rhombus","none"]},width:{control:{type:"number",min:260,max:420,step:10}}},render:r=>({components:{MbInputField:s},setup(){const o=h(r.modelValue??"");return b(()=>r.modelValue,f=>{o.value=f??""}),{args:r,value:o}},template:`
      <div style="display:grid;gap:16px;align-items:start;justify-items:start;padding:24px;">
        <MbInputField v-bind="args" :model-value="value" @update:modelValue="value = $event" />
      </div>
    `})},e={},t={args:{state:"default",label:"Label",leftAddon:"Text",placeholder:"Placeholder",hint:"Hint text",width:320}},a={args:{state:"focus"}};var n,l,i;e.parameters={...e.parameters,docs:{...(n=e.parameters)==null?void 0:n.docs,source:{originalSource:"{}",...(i=(l=e.parameters)==null?void 0:l.docs)==null?void 0:i.source}}};var d,c,u;t.parameters={...t.parameters,docs:{...(d=t.parameters)==null?void 0:d.docs,source:{originalSource:`{
  args: {
    state: 'default',
    label: 'Label',
    leftAddon: 'Text',
    placeholder: 'Placeholder',
    hint: 'Hint text',
    width: 320
  }
}`,...(u=(c=t.parameters)==null?void 0:c.docs)==null?void 0:u.source}}};var p,m,g;a.parameters={...a.parameters,docs:{...(p=a.parameters)==null?void 0:p.docs,source:{originalSource:`{
  args: {
    state: 'focus'
  }
}`,...(g=(m=a.parameters)==null?void 0:m.docs)==null?void 0:g.source}}};const w=["Playground","FigmaDefault","Focus"];export{t as FigmaDefault,a as Focus,e as Playground,w as __namedExportsOrder,F as default};
