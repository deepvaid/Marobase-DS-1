import{_ as o}from"./MbDropdownMenu.vue_vue_type_script_setup_true_lang-GFoFWaHT.js";import"./vue.esm-bundler-BvEW-W-m.js";const l=[{id:"1",label:"Menu Option"},{id:"2",label:"Menu Option"},{id:"3",label:"Menu Option",meta:"Text"},{id:"4",label:"Menu Option",meta:"Text"},{id:"5",label:"Menu Option"},{id:"6",label:"Menu Option"}],c=["default","hover","focus","disabled"],g={title:"Components/MbDropdownMenu",component:o,tags:["autodocs"],args:{header:"Header",footer:"Footer",options:l,selectedId:"",state:"default",disabled:!1,width:260},argTypes:{state:{control:"inline-radio",options:c}},render:p=>({components:{MbDropdownMenu:o},setup(){return{args:p}},template:`
      <div style="display:grid;gap:16px;align-items:start;justify-items:start;padding:24px;">
        <MbDropdownMenu v-bind="args" />
      </div>
    `})},e={},t={args:{selectedId:"3"}};var a,s,r;e.parameters={...e.parameters,docs:{...(a=e.parameters)==null?void 0:a.docs,source:{originalSource:"{}",...(r=(s=e.parameters)==null?void 0:s.docs)==null?void 0:r.source}}};var n,d,i;t.parameters={...t.parameters,docs:{...(n=t.parameters)==null?void 0:n.docs,source:{originalSource:`{
  args: {
    selectedId: '3'
  }
}`,...(i=(d=t.parameters)==null?void 0:d.docs)==null?void 0:i.source}}};const b=["Playground","WithSelection"];export{e as Playground,t as WithSelection,b as __namedExportsOrder,g as default};
