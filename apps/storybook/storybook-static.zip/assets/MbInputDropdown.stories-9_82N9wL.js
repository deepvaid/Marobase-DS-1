import{r as t,w as n}from"./vue.esm-bundler-BvEW-W-m.js";import{_ as p}from"./MbInputDropdown.vue_vue_type_script_setup_true_lang-By8_XMhe.js";const w=[{id:"en",label:"English",meta:"+1",icon:"🇺🇸"},{id:"bg",label:"Български"},{id:"cz",label:"Čeština",meta:"+355",icon:"🇦🇱"},{id:"dk",label:"Dansk",meta:"+213",icon:"🇩🇿"},{id:"de",label:"Deutsch",meta:"+1684",icon:"🇦🇸"},{id:"fr",label:"Français",meta:"+376",icon:"🇦🇩"}],x=["default","hover","focus","disabled","error"],M={title:"Components/MbInputDropdown",component:p,tags:["autodocs"],args:{modelValue:"English",searchValue:"",options:w,label:"Language",placeholder:"Select option",leftAddon:"Text",hint:"Hint text",errorMessage:"Error message",required:!1,open:!0,showSearch:!0,state:"default",disabled:!1},argTypes:{state:{control:"inline-radio",options:x}},render:e=>({components:{MbInputDropdown:p},setup(){const l=t(e.modelValue??""),d=t(e.searchValue??""),c=t(!!e.open);return n(()=>e.modelValue,a=>{l.value=a??""}),n(()=>e.searchValue,a=>{d.value=a??""}),n(()=>e.open,a=>{c.value=!!a}),{args:e,value:l,searchValue:d,open:c}},template:`
      <div style="display:grid;gap:16px;align-items:start;justify-items:start;padding:24px;">
        <MbInputDropdown
          v-bind="args"
          :model-value="value"
          :search-value="searchValue"
          :open="open"
          @update:modelValue="value = $event"
          @update:searchValue="searchValue = $event"
          @update:open="open = $event"
        />
      </div>
    `})},o={},r={args:{open:!1,state:"default"}},s={args:{state:"error",errorMessage:"Please choose one option"}};var u,i,m;o.parameters={...o.parameters,docs:{...(u=o.parameters)==null?void 0:u.docs,source:{originalSource:"{}",...(m=(i=o.parameters)==null?void 0:i.docs)==null?void 0:m.source}}};var g,h,f;r.parameters={...r.parameters,docs:{...(g=r.parameters)==null?void 0:g.docs,source:{originalSource:`{
  args: {
    open: false,
    state: 'default'
  }
}`,...(f=(h=r.parameters)==null?void 0:h.docs)==null?void 0:f.source}}};var v,b,V;s.parameters={...s.parameters,docs:{...(v=s.parameters)==null?void 0:v.docs,source:{originalSource:`{
  args: {
    state: 'error',
    errorMessage: 'Please choose one option'
  }
}`,...(V=(b=s.parameters)==null?void 0:b.docs)==null?void 0:V.source}}};const D=["Playground","Closed","Error"];export{r as Closed,s as Error,o as Playground,D as __namedExportsOrder,M as default};
