import{d as T,e as b,k as v,f,g as $,j as t,o as g,l as H,t as Z}from"./vue.esm-bundler-BvEW-W-m.js";const q=["data-variant","data-state","data-mode","aria-disabled","aria-label","disabled"],z={class:"mb-circle-btn__icon","aria-hidden":"true"},G={key:0,class:"mb-circle-btn__label"},w=T({__name:"MbCircleButton",props:{variant:{default:"neutral"},state:{default:"default"},mode:{default:"icon-only"},label:{default:"Button"},ariaLabel:{default:void 0},disabled:{type:Boolean,default:!1}},emits:["click"],setup(o,{emit:c}){const e=o,u=c,j=t(()=>e.variant),m=t(()=>e.mode),n=t(()=>e.disabled||e.state==="disabled"),E=t(()=>n.value?"disabled":e.state),F=t(()=>{if(m.value==="icon-only")return e.ariaLabel??e.label});function O(a){if(n.value){a.preventDefault(),a.stopPropagation();return}u("click",a)}return(a,p)=>(g(),b("button",{type:"button",class:"mb-circle-btn","data-variant":j.value,"data-state":E.value,"data-mode":m.value,"aria-disabled":n.value?"true":void 0,"aria-label":F.value,disabled:n.value,onClick:O},[v("span",z,[f(a.$slots,"icon",{},()=>[p[0]||(p[0]=v("span",{class:"mb-circle-btn__icon-fallback"},null,-1))])]),m.value==="with-label"?(g(),b("span",G,[f(a.$slots,"default",{},()=>[H(Z(o.label),1)])])):$("",!0)],8,q))}}),J={title:"Components/MbCircleButton",component:w,tags:["autodocs"],args:{variant:"neutral",state:"default",mode:"icon-only",label:"More actions",ariaLabel:"More actions",disabled:!1,iconName:"dots"},argTypes:{variant:{control:"inline-radio",options:["neutral","danger","brand-outline"]},state:{control:"select",options:["default","hover","active","focus","disabled"]},mode:{control:"inline-radio",options:["icon-only","with-label"]},iconName:{control:"inline-radio",options:["dots","heart","cloud-download"]}},render:o=>({components:{MbCircleButton:w},setup(){const c=t(()=>{const{iconName:e,...u}=o;return u});return{args:o,componentArgs:c}},template:`
      <div style="display:grid;gap:16px;align-items:start;justify-items:start;padding:24px;">
        <MbCircleButton v-bind="componentArgs">
          <template #icon>
            <svg
              v-if="args.iconName === 'dots'"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              aria-hidden="true"
            >
              <circle cx="12" cy="6" r="1.8" fill="currentColor" />
              <circle cx="12" cy="12" r="1.8" fill="currentColor" />
              <circle cx="12" cy="18" r="1.8" fill="currentColor" />
            </svg>

            <svg
              v-else-if="args.iconName === 'heart'"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              aria-hidden="true"
            >
              <path
                d="M12 20.25C11.62 20.25 11.27 20.1 11.02 19.85L4.73 13.56C3.19 12.02 3.19 9.52 4.73 7.98C6.27 6.44 8.77 6.44 10.31 7.98L12 9.67L13.69 7.98C15.23 6.44 17.73 6.44 19.27 7.98C20.81 9.52 20.81 12.02 19.27 13.56L12.98 19.85C12.73 20.1 12.38 20.25 12 20.25Z"
                fill="currentColor"
              />
            </svg>

            <svg
              v-else
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              aria-hidden="true"
            >
              <path
                d="M12 16V7.5M12 16L8.75 12.75M12 16L15.25 12.75M5 15.75V16.5C5 18.16 6.34 19.5 8 19.5H16C17.66 19.5 19 18.16 19 16.5V15.75"
                stroke="currentColor"
                stroke-width="1.8"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>
          </template>
        </MbCircleButton>
      </div>
    `})},r={},s={args:{variant:"neutral",mode:"icon-only",state:"default",label:"More actions",ariaLabel:"More actions",iconName:"dots"}},l={args:{variant:"danger",mode:"icon-only",state:"default",label:"Add to favorites",ariaLabel:"Add to favorites",iconName:"heart"}},i={args:{variant:"brand-outline",mode:"with-label",state:"default",label:"Download",iconName:"cloud-download"}},d={name:"Dark Preview (Static reference)",args:{variant:"brand-outline",mode:"with-label",state:"default",label:"Download",iconName:"cloud-download"},parameters:{docs:{description:{story:"Static dark-mode reference snapshot (non-interactive target state)."}},globals:{theme:"dark"}}};var h,y,C;r.parameters={...r.parameters,docs:{...(h=r.parameters)==null?void 0:h.docs,source:{originalSource:"{}",...(C=(y=r.parameters)==null?void 0:y.docs)==null?void 0:C.source}}};var k,M,N;s.parameters={...s.parameters,docs:{...(k=s.parameters)==null?void 0:k.docs,source:{originalSource:`{
  args: {
    variant: 'neutral',
    mode: 'icon-only',
    state: 'default',
    label: 'More actions',
    ariaLabel: 'More actions',
    iconName: 'dots'
  }
}`,...(N=(M=s.parameters)==null?void 0:M.docs)==null?void 0:N.source}}};var L,_,x;l.parameters={...l.parameters,docs:{...(L=l.parameters)==null?void 0:L.docs,source:{originalSource:`{
  args: {
    variant: 'danger',
    mode: 'icon-only',
    state: 'default',
    label: 'Add to favorites',
    ariaLabel: 'Add to favorites',
    iconName: 'heart'
  }
}`,...(x=(_=l.parameters)==null?void 0:_.docs)==null?void 0:x.source}}};var B,D,S;i.parameters={...i.parameters,docs:{...(B=i.parameters)==null?void 0:B.docs,source:{originalSource:`{
  args: {
    variant: 'brand-outline',
    mode: 'with-label',
    state: 'default',
    label: 'Download',
    iconName: 'cloud-download'
  }
}`,...(S=(D=i.parameters)==null?void 0:D.docs)==null?void 0:S.source}}};var A,P,V;d.parameters={...d.parameters,docs:{...(A=d.parameters)==null?void 0:A.docs,source:{originalSource:`{
  name: 'Dark Preview (Static reference)',
  args: {
    variant: 'brand-outline',
    mode: 'with-label',
    state: 'default',
    label: 'Download',
    iconName: 'cloud-download'
  },
  parameters: {
    docs: {
      description: {
        story: 'Static dark-mode reference snapshot (non-interactive target state).'
      }
    },
    globals: {
      theme: 'dark'
    }
  }
}`,...(V=(P=d.parameters)==null?void 0:P.docs)==null?void 0:V.source}}};const K=["Playground","MoreActions","Favorite","Download","DarkPreview"];export{d as DarkPreview,i as Download,l as Favorite,s as MoreActions,r as Playground,K as __namedExportsOrder,J as default};
