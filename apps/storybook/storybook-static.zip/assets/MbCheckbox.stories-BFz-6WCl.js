import{r as o,w as n}from"./vue.esm-bundler-BvEW-W-m.js";import{_ as i}from"./MbCheckbox.vue_vue_type_script_setup_true_lang-CYJpuWYX.js";const z=["default","hover","focus","pressed","disabled","error"],x=["lg","md","sm"],g={title:"Components/MbCheckbox",component:i,tags:["autodocs"],args:{modelValue:!0,indeterminate:!1,size:"lg",state:"default",label:"Label",caption:"",hint:"Hint text",errorMessage:"Error message",required:!1,disabled:!1},argTypes:{size:{control:"inline-radio",options:x},state:{control:"inline-radio",options:z}},render:e=>({components:{MbCheckbox:i},setup(){const r=o(!!e.modelValue),l=o(!!e.indeterminate);return n(()=>e.modelValue,a=>{r.value=!!a}),n(()=>e.indeterminate,a=>{l.value=!!a}),{args:e,checked:r,indeterminate:l}},template:`
      <div style="display:grid;gap:16px;align-items:start;justify-items:start;padding:24px;">
        <MbCheckbox
          v-bind="args"
          :model-value="checked"
          :indeterminate="indeterminate"
          @update:modelValue="checked = $event"
          @update:indeterminate="indeterminate = $event"
        />
      </div>
    `})},t={},s={render:()=>({components:{MbCheckbox:i},setup(){return{states:z,sizes:x}},template:`
      <div style="display:grid;gap:16px;padding:24px;">
        <div v-for="size in sizes" :key="size" style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;align-items:start;">
          <MbCheckbox :size="size" label="Unchecked" state="default" :model-value="false" hint="Hint text" />
          <MbCheckbox :size="size" label="Checked" state="default" :model-value="true" hint="Hint text" />
          <MbCheckbox :size="size" label="Indeterminate" state="default" :indeterminate="true" hint="Hint text" />
          <MbCheckbox :size="size" label="Hover" state="hover" :model-value="true" />
          <MbCheckbox :size="size" label="Focus" state="focus" :model-value="true" />
          <MbCheckbox :size="size" label="Pressed" state="pressed" :model-value="true" />
          <MbCheckbox :size="size" label="Disabled" state="disabled" :model-value="true" />
          <MbCheckbox :size="size" label="Error" state="error" :model-value="true" error-message="Error message" />
        </div>
      </div>
    `})};var d,m,u;t.parameters={...t.parameters,docs:{...(d=t.parameters)==null?void 0:d.docs,source:{originalSource:"{}",...(u=(m=t.parameters)==null?void 0:m.docs)==null?void 0:u.source}}};var c,b,p;s.parameters={...s.parameters,docs:{...(c=s.parameters)==null?void 0:c.docs,source:{originalSource:`{
  render: () => ({
    components: {
      MbCheckbox
    },
    setup() {
      return {
        states: stateOptions,
        sizes: sizeOptions
      };
    },
    template: \`
      <div style="display:grid;gap:16px;padding:24px;">
        <div v-for="size in sizes" :key="size" style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;align-items:start;">
          <MbCheckbox :size="size" label="Unchecked" state="default" :model-value="false" hint="Hint text" />
          <MbCheckbox :size="size" label="Checked" state="default" :model-value="true" hint="Hint text" />
          <MbCheckbox :size="size" label="Indeterminate" state="default" :indeterminate="true" hint="Hint text" />
          <MbCheckbox :size="size" label="Hover" state="hover" :model-value="true" />
          <MbCheckbox :size="size" label="Focus" state="focus" :model-value="true" />
          <MbCheckbox :size="size" label="Pressed" state="pressed" :model-value="true" />
          <MbCheckbox :size="size" label="Disabled" state="disabled" :model-value="true" />
          <MbCheckbox :size="size" label="Error" state="error" :model-value="true" error-message="Error message" />
        </div>
      </div>
    \`
  })
}`,...(p=(b=s.parameters)==null?void 0:b.docs)==null?void 0:p.source}}};const k=["Playground","States"];export{t as Playground,s as States,k as __namedExportsOrder,g as default};
