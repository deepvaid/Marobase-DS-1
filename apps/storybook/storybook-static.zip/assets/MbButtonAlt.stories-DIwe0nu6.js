import{v as s}from"./visual-meta-DVsEdd8r.js";const i={title:"Visual/MbButtonAlt",tags:["autodocs"],render:n=>({setup(){return{args:n}},template:`<section
        data-visual-target
        data-component="MbButtonAlt"
        style="
          width: 100%;
          min-height: 280px;
          border-radius: 12px;
          border: 1px solid #c1c8cd;
          padding: 24px;
          background: var(--mb-surface, #ffffff);
          color: var(--mb-text, #11181c);
          font-family: Inter, sans-serif;
        "
      >
        <h2 style="margin: 0 0 12px; font-size: 20px; line-height: 28px;">MbButtonAlt</h2>
        <p style="margin: 0; font-size: 14px; line-height: 20px;">{{ args.label }}</p>
      </section>`}),args:{label:"MbButtonAlt matrix placeholder. Replace with real component implementation."}},t={parameters:s({figmaNodeId:"820:26374",viewport:"desktop",theme:"light",state:"matrix",variant:"all"})};var e,a,r;t.parameters={...t.parameters,docs:{...(e=t.parameters)==null?void 0:e.docs,source:{originalSource:`{
  parameters: visualParameters({
    figmaNodeId: '820:26374',
    viewport: 'desktop',
    theme: 'light',
    state: 'matrix',
    variant: 'all'
  })
}`,...(r=(a=t.parameters)==null?void 0:a.docs)==null?void 0:r.source}}};const l=["Matrix"];export{t as Matrix,l as __namedExportsOrder,i as default};
