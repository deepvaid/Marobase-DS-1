import{v as s}from"./visual-meta-DVsEdd8r.js";const o={title:"Visual/MbAvatarStack",tags:["autodocs"],render:n=>({setup(){return{args:n}},template:`<section
        data-visual-target
        data-component="MbAvatarStack"
        style="
          width: 100%;
          min-height: 280px;
          border-radius: 12px;
          border: 1px solid #c1c8cd;
          padding: 24px;
          background: var(--mb-surface, #ffffff);
          color: var(--mb-text, #11181c);
          font-family: Inter, sans-serif;
        "
      >
        <h2 style="margin: 0 0 12px; font-size: 20px; line-height: 28px;">MbAvatarStack</h2>
        <p style="margin: 0; font-size: 14px; line-height: 20px;">{{ args.label }}</p>
      </section>`}),args:{label:"MbAvatarStack matrix placeholder. Replace with real component implementation."}},a={parameters:s({figmaNodeId:"1352:125063",viewport:"desktop",theme:"light",state:"matrix",variant:"all"})};var t,e,r;a.parameters={...a.parameters,docs:{...(t=a.parameters)==null?void 0:t.docs,source:{originalSource:`{
  parameters: visualParameters({
    figmaNodeId: '1352:125063',
    viewport: 'desktop',
    theme: 'light',
    state: 'matrix',
    variant: 'all'
  })
}`,...(r=(e=a.parameters)==null?void 0:e.docs)==null?void 0:r.source}}};const p=["Matrix"];export{a as Matrix,p as __namedExportsOrder,o as default};
