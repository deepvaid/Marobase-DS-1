const l={globalTypes:{theme:{name:"Theme",description:"Global visual theme",defaultValue:"light",toolbar:{icon:"mirror",items:[{value:"light",title:"Light"},{value:"dark",title:"Dark"}]}}},parameters:{controls:{expanded:!0},backgrounds:{disable:!0}},decorators:[(e,r)=>({components:{story:e},setup(){const s=String(r.globals.theme??"light"),o=!!r.parameters.visualParity;if(typeof document<"u"){const t=s==="dark",a=document.documentElement,i=document.body;a.dataset.theme=s,a.classList.toggle("theme-dark",t),a.classList.toggle("theme-light",!t),a.classList.toggle("v-theme--dark",t),a.classList.toggle("v-theme--light",!t),i&&(i.classList.toggle("theme-dark",t),i.classList.toggle("theme-light",!t),i.classList.toggle("v-theme--dark",t),i.classList.toggle("v-theme--light",!t))}return{theme:s,isVisualParity:o}},template:`
        <div
          data-visual-root
          class="mb-preview-root"
          :class="theme === 'dark' ? 'mb-preview-root--dark' : 'mb-preview-root--light'"
          :data-theme="theme"
        >
          <div v-if="isVisualParity" data-visual-target="stage" class="mb-visual-stage mb-visual-stage--parity">
            <div class="mb-visual-stage__content">
              <story />
            </div>
          </div>
          <div v-else class="mb-interactive-shell">
            <div class="v-application mb-v-app" :class="theme === 'dark' ? 'v-theme--dark' : 'v-theme--light'" data-app="true">
              <div class="v-application__wrap mb-v-app__wrap">
                <story />
              </div>
            </div>
          </div>
        </div>
      `})]};if(typeof document<"u"&&!document.getElementById("mb-visual-stage-style")){const e=document.createElement("style");e.id="mb-visual-stage-style",e.textContent=`
    :root {
      --mb-stage-bg: #f2f4f8;
      --mb-stage-border: #d0d5dd;
      --mb-stage-text: #1f2630;
    }

    html[data-theme='dark'],
    html.theme-dark,
    html.v-theme--dark {
      --mb-stage-bg: #0f141c;
      --mb-stage-border: #2a3342;
      --mb-stage-text: #e5eaf2;
    }

    .mb-preview-root {
      min-height: 100vh;
      color: var(--mb-stage-text);
    }

    .mb-interactive-shell {
      min-height: 100vh;
      width: 100%;
    }

    .mb-v-app {
      min-height: 100vh;
      width: 100%;
      color: var(--mb-stage-text);
      background: transparent;
    }

    .mb-v-app__wrap {
      min-height: 100vh;
      width: 100%;
    }

    .mb-visual-stage {
      width: 960px;
      height: 540px;
      padding: 24px;
      box-sizing: border-box;
      overflow: hidden;
      display: grid;
      place-items: center;
      margin: 0 auto;
      background: var(--mb-stage-bg);
      border: 1px solid var(--mb-stage-border);
      color: var(--mb-stage-text);
    }

    .mb-visual-stage__content {
      width: 100%;
      height: 100%;
      min-width: 0;
      min-height: 0;
      overflow: hidden;
      display: grid;
      place-items: center;
      box-sizing: border-box;
      contain: strict;
    }

    .mb-visual-stage--parity,
    .mb-visual-stage--parity *,
    .mb-visual-stage--parity *::before,
    .mb-visual-stage--parity *::after {
      animation: none !important;
      transition: none !important;
      caret-color: transparent !important;
    }
  `,document.head.appendChild(e)}export{l as default};
