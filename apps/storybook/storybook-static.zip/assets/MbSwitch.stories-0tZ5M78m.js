import{r as d,w as n}from"./vue.esm-bundler-BvEW-W-m.js";import{_ as i}from"./MbSwitch.vue_vue_type_script_setup_true_lang-2n5cs-7u.js";const v=["default","hover","focus","pressed","disabled","error"],z=["md","sm"],f={title:"Components/MbSwitch",component:i,tags:["autodocs"],args:{modelValue:!1,indeterminate:!1,loading:!1,size:"md",state:"default",label:"Label",caption:"",hint:"Hint text",errorMessage:"Error message",disabled:!1},argTypes:{size:{control:"inline-radio",options:z},state:{control:"inline-radio",options:v}},render:e=>({components:{MbSwitch:i},setup(){const l=d(!!e.modelValue),r=d(!!e.indeterminate);return n(()=>e.modelValue,a=>{l.value=!!a}),n(()=>e.indeterminate,a=>{r.value=!!a}),{args:e,checked:l,indeterminate:r}},template:`
      <div style="display:grid;gap:16px;align-items:start;justify-items:start;padding:24px;">
        <MbSwitch
          v-bind="args"
          :model-value="checked"
          :indeterminate="indeterminate"
          @update:modelValue="checked = $event"
          @update:indeterminate="indeterminate = $event"
        />
      </div>
    `})},t={},s={render:()=>({components:{MbSwitch:i},setup(){return{sizes:z}},template:`
      <div style="display:grid;gap:16px;padding:24px;">
        <div v-for="size in sizes" :key="size" style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;align-items:start;">
          <MbSwitch :size="size" label="Unchecked" state="default" :model-value="false" />
          <MbSwitch :size="size" label="Checked" state="default" :model-value="true" />
          <MbSwitch :size="size" label="Indeterminate" state="default" :indeterminate="true" />
          <MbSwitch :size="size" label="Hover" state="hover" :model-value="true" />
          <MbSwitch :size="size" label="Focus" state="focus" :model-value="true" />
          <MbSwitch :size="size" label="Pressed" state="pressed" :model-value="true" />
          <MbSwitch :size="size" label="Loading" state="default" :model-value="true" :loading="true" />
          <MbSwitch :size="size" label="Disabled" state="disabled" :model-value="true" />
          <MbSwitch :size="size" label="Error" state="error" :model-value="true" error-message="Error message" />
        </div>
      </div>
    `})};var o,u,m;t.parameters={...t.parameters,docs:{...(o=t.parameters)==null?void 0:o.docs,source:{originalSource:"{}",...(m=(u=t.parameters)==null?void 0:u.docs)==null?void 0:m.source}}};var c,p,b;s.parameters={...s.parameters,docs:{...(c=s.parameters)==null?void 0:c.docs,source:{originalSource:`{
  render: () => ({
    components: {
      MbSwitch
    },
    setup() {
      return {
        sizes: sizeOptions
      };
    },
    template: \`
      <div style="display:grid;gap:16px;padding:24px;">
        <div v-for="size in sizes" :key="size" style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;align-items:start;">
          <MbSwitch :size="size" label="Unchecked" state="default" :model-value="false" />
          <MbSwitch :size="size" label="Checked" state="default" :model-value="true" />
          <MbSwitch :size="size" label="Indeterminate" state="default" :indeterminate="true" />
          <MbSwitch :size="size" label="Hover" state="hover" :model-value="true" />
          <MbSwitch :size="size" label="Focus" state="focus" :model-value="true" />
          <MbSwitch :size="size" label="Pressed" state="pressed" :model-value="true" />
          <MbSwitch :size="size" label="Loading" state="default" :model-value="true" :loading="true" />
          <MbSwitch :size="size" label="Disabled" state="disabled" :model-value="true" />
          <MbSwitch :size="size" label="Error" state="error" :model-value="true" error-message="Error message" />
        </div>
      </div>
    \`
  })
}`,...(b=(p=s.parameters)==null?void 0:p.docs)==null?void 0:b.source}}};const S=["Playground","States"];export{t as Playground,s as States,S as __namedExportsOrder,f as default};
