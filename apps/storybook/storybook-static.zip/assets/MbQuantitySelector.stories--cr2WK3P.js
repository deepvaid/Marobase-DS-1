import{v as i}from"./visual-meta-DVsEdd8r.js";const o={title:"Visual/MbQuantitySelector",tags:["autodocs"],render:n=>({setup(){return{args:n}},template:`<section
        data-visual-target
        data-component="MbQuantitySelector"
        style="
          width: 100%;
          min-height: 280px;
          border-radius: 12px;
          border: 1px solid #c1c8cd;
          padding: 24px;
          background: var(--mb-surface, #ffffff);
          color: var(--mb-text, #11181c);
          font-family: Inter, sans-serif;
        "
      >
        <h2 style="margin: 0 0 12px; font-size: 20px; line-height: 28px;">MbQuantitySelector</h2>
        <p style="margin: 0; font-size: 14px; line-height: 20px;">{{ args.label }}</p>
      </section>`}),args:{label:"MbQuantitySelector matrix placeholder. Replace with real component implementation."}},e={parameters:i({figmaNodeId:"1233:48039",viewport:"desktop",theme:"light",state:"matrix",variant:"all"})};var t,a,r;e.parameters={...e.parameters,docs:{...(t=e.parameters)==null?void 0:t.docs,source:{originalSource:`{
  parameters: visualParameters({
    figmaNodeId: '1233:48039',
    viewport: 'desktop',
    theme: 'light',
    state: 'matrix',
    variant: 'all'
  })
}`,...(r=(a=e.parameters)==null?void 0:a.docs)==null?void 0:r.source}}};const l=["Matrix"];export{e as Matrix,l as __namedExportsOrder,o as default};
