import{r as c,w as b}from"./vue.esm-bundler-BvEW-W-m.js";import{_ as t}from"./MbRadio.vue_vue_type_script_setup_true_lang-BmVkNinh.js";const z=["default","hover","focus","pressed","disabled","error"],m=["lg","md","sm"],f={title:"Components/MbRadio",component:t,tags:["autodocs"],args:{modelValue:!1,size:"lg",state:"default",label:"Label",caption:"",hint:"Hint text",errorMessage:"Error message",allowDeselect:!1,required:!1,disabled:!1},argTypes:{size:{control:"inline-radio",options:m},state:{control:"inline-radio",options:z}},render:a=>({components:{MbRadio:t},setup(){const i=c(!!a.modelValue);return b(()=>a.modelValue,p=>{i.value=!!p}),{args:a,checked:i}},template:`
      <div style="display:grid;gap:16px;align-items:start;justify-items:start;padding:24px;">
        <MbRadio v-bind="args" :model-value="checked" @update:modelValue="checked = $event" />
      </div>
    `})},e={},s={render:()=>({components:{MbRadio:t},setup(){return{sizes:m}},template:`
      <div style="display:grid;gap:16px;padding:24px;">
        <div v-for="size in sizes" :key="size" style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;align-items:start;">
          <MbRadio :size="size" label="Unchecked" state="default" :model-value="false" hint="Hint text" />
          <MbRadio :size="size" label="Checked" state="default" :model-value="true" hint="Hint text" />
          <MbRadio :size="size" label="Hover" state="hover" :model-value="true" />
          <MbRadio :size="size" label="Focus" state="focus" :model-value="true" />
          <MbRadio :size="size" label="Pressed" state="pressed" :model-value="true" />
          <MbRadio :size="size" label="Disabled" state="disabled" :model-value="true" />
          <MbRadio :size="size" label="Error" state="error" :model-value="true" error-message="Error message" />
        </div>
      </div>
    `})};var r,l,o;e.parameters={...e.parameters,docs:{...(r=e.parameters)==null?void 0:r.docs,source:{originalSource:"{}",...(o=(l=e.parameters)==null?void 0:l.docs)==null?void 0:o.source}}};var d,n,u;s.parameters={...s.parameters,docs:{...(d=s.parameters)==null?void 0:d.docs,source:{originalSource:`{
  render: () => ({
    components: {
      MbRadio
    },
    setup() {
      return {
        sizes: sizeOptions
      };
    },
    template: \`
      <div style="display:grid;gap:16px;padding:24px;">
        <div v-for="size in sizes" :key="size" style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;align-items:start;">
          <MbRadio :size="size" label="Unchecked" state="default" :model-value="false" hint="Hint text" />
          <MbRadio :size="size" label="Checked" state="default" :model-value="true" hint="Hint text" />
          <MbRadio :size="size" label="Hover" state="hover" :model-value="true" />
          <MbRadio :size="size" label="Focus" state="focus" :model-value="true" />
          <MbRadio :size="size" label="Pressed" state="pressed" :model-value="true" />
          <MbRadio :size="size" label="Disabled" state="disabled" :model-value="true" />
          <MbRadio :size="size" label="Error" state="error" :model-value="true" error-message="Error message" />
        </div>
      </div>
    \`
  })
}`,...(u=(n=s.parameters)==null?void 0:n.docs)==null?void 0:u.source}}};const M=["Playground","States"];export{e as Playground,s as States,M as __namedExportsOrder,f as default};
