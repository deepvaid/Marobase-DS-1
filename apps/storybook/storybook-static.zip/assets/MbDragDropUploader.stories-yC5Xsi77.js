import{v as o}from"./visual-meta-DVsEdd8r.js";const i={title:"Visual/MbDragDropUploader",tags:["autodocs"],render:n=>({setup(){return{args:n}},template:`<section
        data-visual-target
        data-component="MbDragDropUploader"
        style="
          width: 100%;
          min-height: 280px;
          border-radius: 12px;
          border: 1px solid #c1c8cd;
          padding: 24px;
          background: var(--mb-surface, #ffffff);
          color: var(--mb-text, #11181c);
          font-family: Inter, sans-serif;
        "
      >
        <h2 style="margin: 0 0 12px; font-size: 20px; line-height: 28px;">MbDragDropUploader</h2>
        <p style="margin: 0; font-size: 14px; line-height: 20px;">{{ args.label }}</p>
      </section>`}),args:{label:"MbDragDropUploader matrix placeholder. Replace with real component implementation."}},e={parameters:o({figmaNodeId:"981:23650",viewport:"desktop",theme:"light",state:"matrix",variant:"all"})};var a,r,t;e.parameters={...e.parameters,docs:{...(a=e.parameters)==null?void 0:a.docs,source:{originalSource:`{
  parameters: visualParameters({
    figmaNodeId: '981:23650',
    viewport: 'desktop',
    theme: 'light',
    state: 'matrix',
    variant: 'all'
  })
}`,...(t=(r=e.parameters)==null?void 0:r.docs)==null?void 0:t.source}}};const p=["Matrix"];export{e as Matrix,p as __namedExportsOrder,i as default};
