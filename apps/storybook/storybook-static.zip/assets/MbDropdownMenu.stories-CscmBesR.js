import{_ as o}from"./MbDropdownMenu.vue_vue_type_script_setup_true_lang-GFoFWaHT.js";import{v as i}from"./visual-meta-DVsEdd8r.js";import"./vue.esm-bundler-BvEW-W-m.js";const n={title:"Visual/MbDropdownMenu",tags:["autodocs"],render:()=>({components:{MbDropdownMenu:o},template:`
      <section data-visual-target class="mbvdm-root" aria-label="MbDropdownMenu visual matrix">
        <h2 class="mbvdm-title">MbDropdownMenu</h2>

        <div class="mbvdm-grid">
          <MbDropdownMenu header="Header" footer="Footer" :width="260" />
          <MbDropdownMenu header="Header" footer="Footer" :width="260" state="hover" />
          <MbDropdownMenu header="Header" footer="Footer" :width="260" state="focus" selected-id="3" />
        </div>

        <style>
          .mbvdm-root {
            width: 100%;
            min-height: 100%;
            padding: 12px;
            box-sizing: border-box;
            background: var(--mb-stage-bg);
            color: var(--mb-stage-text);
            border: 1px solid var(--mb-stage-border);
            border-radius: 12px;
            font-family: var(--mb-dm-font-family);
            display: grid;
            gap: 10px;
          }

          .mbvdm-title {
            margin: 0;
            font-size: 18px;
            line-height: 24px;
          }

          .mbvdm-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            justify-items: center;
            gap: 10px;
          }
        </style>
      </section>
    `})},e={parameters:i({figmaNodeId:"3809:144950",viewport:"desktop",theme:"light",state:"matrix",variant:"all"})};var r,t,a;e.parameters={...e.parameters,docs:{...(r=e.parameters)==null?void 0:r.docs,source:{originalSource:`{
  parameters: visualParameters({
    figmaNodeId: '3809:144950',
    viewport: 'desktop',
    theme: 'light',
    state: 'matrix',
    variant: 'all'
  })
}`,...(a=(t=e.parameters)==null?void 0:t.docs)==null?void 0:a.source}}};const p=["Matrix"];export{e as Matrix,p as __namedExportsOrder,n as default};
