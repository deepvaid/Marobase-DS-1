import{v as s}from"./visual-meta-DVsEdd8r.js";const o={title:"Visual/MbRadiusEffectsFoundation",tags:["autodocs"],render:r=>({setup(){return{args:r}},template:`<section
        data-visual-target
        data-component="MbRadiusEffectsFoundation"
        style="
          width: 100%;
          min-height: 280px;
          border-radius: 12px;
          border: 1px solid #c1c8cd;
          padding: 24px;
          background: var(--mb-surface, #ffffff);
          color: var(--mb-text, #11181c);
          font-family: Inter, sans-serif;
        "
      >
        <h2 style="margin: 0 0 12px; font-size: 20px; line-height: 28px;">MbRadiusEffectsFoundation</h2>
        <p style="margin: 0; font-size: 14px; line-height: 20px;">{{ args.label }}</p>
      </section>`}),args:{label:"MbRadiusEffectsFoundation matrix placeholder. Replace with real component implementation."}},e={parameters:s({figmaNodeId:"408:7864",viewport:"desktop",theme:"light",state:"matrix",variant:"all"})};var a,t,n;e.parameters={...e.parameters,docs:{...(a=e.parameters)==null?void 0:a.docs,source:{originalSource:`{
  parameters: visualParameters({
    figmaNodeId: '408:7864',
    viewport: 'desktop',
    theme: 'light',
    state: 'matrix',
    variant: 'all'
  })
}`,...(n=(t=e.parameters)==null?void 0:t.docs)==null?void 0:n.source}}};const d=["Matrix"];export{e as Matrix,d as __namedExportsOrder,o as default};
