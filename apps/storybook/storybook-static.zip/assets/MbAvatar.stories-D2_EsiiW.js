import{d as _,e as r,t as k,p as C,j as n,o as l}from"./vue.esm-bundler-BvEW-W-m.js";const J=["data-size","data-tone","data-interactive","disabled","aria-label"],L=["src","alt"],P={key:1,class:"mb-av__initials","aria-hidden":"true"},o=_({__name:"MbAvatar",props:{name:{default:"Jane Smith"},initials:{default:""},src:{default:""},alt:{default:""},size:{default:"lg"},tone:{default:"neutral"},interactive:{type:Boolean,default:!1},disabled:{type:Boolean,default:!1},ariaLabel:{default:void 0}},emits:["click"],setup(a,{emit:y}){const e=a,x=y,M={sm:24,md:32,lg:48,xl:64},A=n(()=>M[e.size]),z=n(()=>({"--mb-av-size":`${A.value}px`})),d=n(()=>{if(e.initials.trim().length>0)return e.initials.trim().slice(0,2).toUpperCase();const t=e.name.trim().split(/\s+/).filter(Boolean).slice(0,2);return t.length===0?"MB":t.map(p=>p[0].toUpperCase()).join("")}),S=n(()=>e.disabled||!e.interactive),c=n(()=>e.alt||e.name||d.value),h=n(()=>e.ariaLabel??c.value);function B(t){if(e.disabled){t.preventDefault();return}x("click",t)}return(t,p)=>(l(),r("button",{type:"button",class:"mb-av",style:C(z.value),"data-size":a.size,"data-tone":a.tone,"data-interactive":a.interactive?"true":"false",disabled:S.value,"aria-label":h.value,onClick:B},[a.src?(l(),r("img",{key:0,class:"mb-av__image",src:a.src,alt:c.value},null,8,L)):(l(),r("span",P,k(d.value),1))],12,J))}}),j=["sm","md","lg","xl"],D=["neutral","brand","danger"],T={title:"Components/MbAvatar",component:o,tags:["autodocs"],args:{name:"Jane Smith",initials:"JS",size:"lg",tone:"neutral",interactive:!0,disabled:!1},argTypes:{size:{control:"inline-radio",options:j},tone:{control:"inline-radio",options:D}},render:a=>({components:{MbAvatar:o},setup(){return{args:a}},template:`
      <div style="display:grid;gap:16px;align-items:start;justify-items:start;padding:24px;">
        <MbAvatar v-bind="args" />
      </div>
    `})},i={},s={render:a=>({components:{MbAvatar:o},setup(){return{args:a}},template:`
      <div style="display:flex;gap:16px;padding:24px;align-items:center;">
        <MbAvatar v-bind="args" tone="neutral" initials="JS" />
        <MbAvatar v-bind="args" tone="brand" initials="MB" />
        <MbAvatar v-bind="args" tone="danger" initials="AL" />
      </div>
    `})};var u,m,v;i.parameters={...i.parameters,docs:{...(u=i.parameters)==null?void 0:u.docs,source:{originalSource:"{}",...(v=(m=i.parameters)==null?void 0:m.docs)==null?void 0:v.source}}};var b,g,f;s.parameters={...s.parameters,docs:{...(b=s.parameters)==null?void 0:b.docs,source:{originalSource:`{
  render: args => ({
    components: {
      MbAvatar
    },
    setup() {
      return {
        args
      };
    },
    template: \`
      <div style="display:flex;gap:16px;padding:24px;align-items:center;">
        <MbAvatar v-bind="args" tone="neutral" initials="JS" />
        <MbAvatar v-bind="args" tone="brand" initials="MB" />
        <MbAvatar v-bind="args" tone="danger" initials="AL" />
      </div>
    \`
  })
}`,...(f=(g=s.parameters)==null?void 0:g.docs)==null?void 0:f.source}}};const E=["Playground","ToneGrid"];export{i as Playground,s as ToneGrid,E as __namedExportsOrder,T as default};
