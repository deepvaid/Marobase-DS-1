import{r as h,w as f}from"./vue.esm-bundler-BvEW-W-m.js";import{_ as r}from"./MbButtonGroup.vue_vue_type_script_setup_true_lang-DAzBZkz6.js";const y=[{id:"view",icon:"eye",ariaLabel:"View"},{id:"edit",icon:"pencil",ariaLabel:"Edit"},{id:"delete",icon:"trash",ariaLabel:"Delete"}],v={title:"Components/MbButtonGroup",component:r,tags:["autodocs"],args:{items:y,modelValue:0,size:"lg",mode:"icon-only",hug:!1,disabled:!1,ariaLabel:"Button group"},argTypes:{size:{control:"inline-radio",options:["lg","md","sm"]},mode:{control:"inline-radio",options:["icon-only","with-label"]},hug:{control:"boolean"},modelValue:{control:{type:"number",min:0,max:2,step:1}}},render:e=>({components:{MbButtonGroup:r},setup(){const i=h(typeof e.modelValue=="number"?e.modelValue:0);return f(()=>e.modelValue,n=>{typeof n=="number"&&Number.isFinite(n)&&(i.value=n)}),{args:e,selected:i}},template:`
      <div style="display:grid;gap:16px;align-items:start;justify-items:start;padding:24px;">
        <MbButtonGroup
          v-bind="args"
          :model-value="selected"
          @update:modelValue="selected = $event"
        />
      </div>
    `})},o={},a={args:{size:"lg",mode:"icon-only",hug:!1,modelValue:0}},t={args:{mode:"with-label",hug:!0,items:[{id:"first",label:"View",icon:"eye"},{id:"second",label:"Edit",icon:"pencil"},{id:"third",label:"Delete",icon:"trash"}]}};var l,s,d;o.parameters={...o.parameters,docs:{...(l=o.parameters)==null?void 0:l.docs,source:{originalSource:"{}",...(d=(s=o.parameters)==null?void 0:s.docs)==null?void 0:d.source}}};var m,c,u;a.parameters={...a.parameters,docs:{...(m=a.parameters)==null?void 0:m.docs,source:{originalSource:`{
  args: {
    size: 'lg',
    mode: 'icon-only',
    hug: false,
    modelValue: 0
  }
}`,...(u=(c=a.parameters)==null?void 0:c.docs)==null?void 0:u.source}}};var p,g,b;t.parameters={...t.parameters,docs:{...(p=t.parameters)==null?void 0:p.docs,source:{originalSource:`{
  args: {
    mode: 'with-label',
    hug: true,
    items: [{
      id: 'first',
      label: 'View',
      icon: 'eye'
    }, {
      id: 'second',
      label: 'Edit',
      icon: 'pencil'
    }, {
      id: 'third',
      label: 'Delete',
      icon: 'trash'
    }]
  }
}`,...(b=(g=t.parameters)==null?void 0:g.docs)==null?void 0:b.source}}};const L=["Playground","FigmaSegmented","WithLabel"];export{a as FigmaSegmented,o as Playground,t as WithLabel,L as __namedExportsOrder,v as default};
