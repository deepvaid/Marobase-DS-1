import{_ as n}from"./MbButton.vue_vue_type_script_setup_true_lang-BaRAgLYQ.js";import"./vue.esm-bundler-BvEW-W-m.js";const y={title:"Components/MbButton",component:n,tags:["autodocs"],args:{styleType:"filled",size:"lg",state:"default",iconMode:"with-label",label:"Sign Up",leadingIcon:void 0,trailingIcon:void 0,disabled:!1,loading:!1},argTypes:{styleType:{control:"inline-radio",options:["filled","outline","tinted","plain"]},size:{control:"inline-radio",options:["lg","md","sm"]},state:{control:"select",options:["default","hover","active","focus","disabled","loading"]},iconMode:{control:"inline-radio",options:["with-label","icon-only"]}},render:g=>({components:{MbButton:n},setup(){return{args:g}},template:`
      <div style="display:grid;gap:12px;align-items:start;justify-items:start;padding:24px;">
        <MbButton v-bind="args" />
      </div>
    `})},e={},t={name:"Figma Primary (Static reference)",args:{styleType:"filled",size:"lg",state:"default",iconMode:"with-label",label:"Sign Up",leadingIcon:void 0,trailingIcon:void 0},parameters:{docs:{description:{story:"Static Figma reference snapshot (non-interactive target state)."}}}},a={name:"Dark Preview (Static reference)",parameters:{docs:{description:{story:"Static dark-mode reference snapshot (non-interactive target state)."}},globals:{theme:"dark"}}};var r,i,o;e.parameters={...e.parameters,docs:{...(r=e.parameters)==null?void 0:r.docs,source:{originalSource:"{}",...(o=(i=e.parameters)==null?void 0:i.docs)==null?void 0:o.source}}};var s,c,l;t.parameters={...t.parameters,docs:{...(s=t.parameters)==null?void 0:s.docs,source:{originalSource:`{
  name: 'Figma Primary (Static reference)',
  args: {
    styleType: 'filled',
    size: 'lg',
    state: 'default',
    iconMode: 'with-label',
    label: 'Sign Up',
    leadingIcon: undefined,
    trailingIcon: undefined
  },
  parameters: {
    docs: {
      description: {
        story: 'Static Figma reference snapshot (non-interactive target state).'
      }
    }
  }
}`,...(l=(c=t.parameters)==null?void 0:c.docs)==null?void 0:l.source}}};var d,p,m;a.parameters={...a.parameters,docs:{...(d=a.parameters)==null?void 0:d.docs,source:{originalSource:`{
  name: 'Dark Preview (Static reference)',
  parameters: {
    docs: {
      description: {
        story: 'Static dark-mode reference snapshot (non-interactive target state).'
      }
    },
    globals: {
      theme: 'dark'
    }
  }
}`,...(m=(p=a.parameters)==null?void 0:p.docs)==null?void 0:m.source}}};const v=["Playground","FigmaPrimary","DarkPreview"];export{a as DarkPreview,t as FigmaPrimary,e as Playground,v as __namedExportsOrder,y as default};
