import{v as i}from"./visual-meta-DVsEdd8r.js";const l={title:"Visual/MbMultiSelect",tags:["autodocs"],render:n=>({setup(){return{args:n}},template:`<section
        data-visual-target
        data-component="MbMultiSelect"
        style="
          width: 100%;
          min-height: 280px;
          border-radius: 12px;
          border: 1px solid #c1c8cd;
          padding: 24px;
          background: var(--mb-surface, #ffffff);
          color: var(--mb-text, #11181c);
          font-family: Inter, sans-serif;
        "
      >
        <h2 style="margin: 0 0 12px; font-size: 20px; line-height: 28px;">MbMultiSelect</h2>
        <p style="margin: 0; font-size: 14px; line-height: 20px;">{{ args.label }}</p>
      </section>`}),args:{label:"MbMultiSelect matrix placeholder. Replace with real component implementation."}},e={parameters:i({figmaNodeId:"981:23648",viewport:"desktop",theme:"light",state:"matrix",variant:"all"})};var t,a,r;e.parameters={...e.parameters,docs:{...(t=e.parameters)==null?void 0:t.docs,source:{originalSource:`{
  parameters: visualParameters({
    figmaNodeId: '981:23648',
    viewport: 'desktop',
    theme: 'light',
    state: 'matrix',
    variant: 'all'
  })
}`,...(r=(a=e.parameters)==null?void 0:a.docs)==null?void 0:r.source}}};const o=["Matrix"];export{e as Matrix,o as __namedExportsOrder,l as default};
