import{d as M,e as r,k as t,g as _,t as h,j as o,o as i}from"./vue.esm-bundler-BvEW-W-m.js";const C=["data-tone","data-variant","data-interactive","disabled","aria-label"],P={key:0,class:"mb-badge__icon","aria-hidden":"true"},D={key:0,viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg"},O={key:1,viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg"},V={class:"mb-badge__label"},c=M({__name:"MbBadge",props:{label:{default:"Premium"},tone:{default:"additional"},variant:{default:"outline"},icon:{default:"star"},interactive:{type:Boolean,default:!1},disabled:{type:Boolean,default:!1},ariaLabel:{default:void 0}},emits:["click"],setup(e,{emit:y}){const a=e,k=y,x=o(()=>a.variant==="outline"?"outline":a.variant),B=o(()=>a.disabled||!a.interactive),u=o(()=>a.icon),w=o(()=>a.ariaLabel??a.label);function L(d){if(a.disabled){d.preventDefault();return}k("click",d)}return(d,n)=>(i(),r("button",{type:"button",class:"mb-badge","data-tone":e.tone,"data-variant":x.value,"data-interactive":e.interactive?"true":"false",disabled:B.value,"aria-label":w.value,onClick:L},[u.value!=="none"?(i(),r("span",P,[u.value==="star"?(i(),r("svg",D,[...n[0]||(n[0]=[t("path",{d:"M12 3.4L14.7 8.8L20.7 9.7L16.4 13.9L17.4 19.9L12 17.1L6.6 19.9L7.6 13.9L3.3 9.7L9.3 8.8L12 3.4Z",stroke:"currentColor","stroke-width":"1.8","stroke-linejoin":"round"},null,-1)])])):(i(),r("svg",O,[...n[1]||(n[1]=[t("circle",{cx:"12",cy:"12",r:"9",stroke:"currentColor","stroke-width":"1.8"},null,-1),t("path",{d:"M12 7.8V12.5",stroke:"currentColor","stroke-width":"1.8","stroke-linecap":"round"},null,-1),t("circle",{cx:"12",cy:"16.2",r:"1.1",fill:"currentColor"},null,-1)])]))])):_("",!0),t("span",V,h(e.label),1)],8,C))}}),j=["additional","danger","success","brand","neutral"],S=["outline","soft","solid"],A=["star","alert","none"],N={title:"Components/MbBadge",component:c,tags:["autodocs"],args:{label:"Premium",tone:"additional",variant:"outline",icon:"star",interactive:!0,disabled:!1},argTypes:{tone:{control:"inline-radio",options:j},variant:{control:"inline-radio",options:S},icon:{control:"inline-radio",options:A}},render:e=>({components:{MbBadge:c},setup(){return{args:e}},template:`
      <div style="display:grid;gap:16px;align-items:start;justify-items:start;padding:24px;">
        <MbBadge v-bind="args" />
      </div>
    `})},s={},l={render:e=>({components:{MbBadge:c},setup(){return{args:e}},template:`
      <div style="display:flex;gap:12px;padding:24px;align-items:center;">
        <MbBadge v-bind="args" label="Premium" tone="additional" variant="outline" icon="star" />
        <MbBadge v-bind="args" label="Danger" tone="danger" variant="soft" icon="alert" />
      </div>
    `})};var p,g,m;s.parameters={...s.parameters,docs:{...(p=s.parameters)==null?void 0:p.docs,source:{originalSource:"{}",...(m=(g=s.parameters)==null?void 0:g.docs)==null?void 0:m.source}}};var b,v,f;l.parameters={...l.parameters,docs:{...(b=l.parameters)==null?void 0:b.docs,source:{originalSource:`{
  render: args => ({
    components: {
      MbBadge
    },
    setup() {
      return {
        args
      };
    },
    template: \`
      <div style="display:flex;gap:12px;padding:24px;align-items:center;">
        <MbBadge v-bind="args" label="Premium" tone="additional" variant="outline" icon="star" />
        <MbBadge v-bind="args" label="Danger" tone="danger" variant="soft" icon="alert" />
      </div>
    \`
  })
}`,...(f=(v=l.parameters)==null?void 0:v.docs)==null?void 0:f.source}}};const T=["Playground","PremiumAndDanger"];export{s as Playground,l as PremiumAndDanger,T as __namedExportsOrder,N as default};
