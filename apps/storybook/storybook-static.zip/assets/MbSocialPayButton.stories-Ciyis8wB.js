import{v as o}from"./visual-meta-DVsEdd8r.js";const s={title:"Visual/MbSocialPayButton",tags:["autodocs"],render:n=>({setup(){return{args:n}},template:`<section
        data-visual-target
        data-component="MbSocialPayButton"
        style="
          width: 100%;
          min-height: 280px;
          border-radius: 12px;
          border: 1px solid #c1c8cd;
          padding: 24px;
          background: var(--mb-surface, #ffffff);
          color: var(--mb-text, #11181c);
          font-family: Inter, sans-serif;
        "
      >
        <h2 style="margin: 0 0 12px; font-size: 20px; line-height: 28px;">MbSocialPayButton</h2>
        <p style="margin: 0; font-size: 14px; line-height: 20px;">{{ args.label }}</p>
      </section>`}),args:{label:"MbSocialPayButton matrix placeholder. Replace with real component implementation."}},a={parameters:o({figmaNodeId:"895:35143",viewport:"desktop",theme:"light",state:"matrix",variant:"all"})};var t,e,r;a.parameters={...a.parameters,docs:{...(t=a.parameters)==null?void 0:t.docs,source:{originalSource:`{
  parameters: visualParameters({
    figmaNodeId: '895:35143',
    viewport: 'desktop',
    theme: 'light',
    state: 'matrix',
    variant: 'all'
  })
}`,...(r=(e=a.parameters)==null?void 0:e.docs)==null?void 0:r.source}}};const l=["Matrix"];export{a as Matrix,l as __namedExportsOrder,s as default};
