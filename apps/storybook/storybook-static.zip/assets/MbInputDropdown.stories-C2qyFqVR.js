import{_ as o}from"./MbInputDropdown.vue_vue_type_script_setup_true_lang-By8_XMhe.js";import{v as s}from"./visual-meta-DVsEdd8r.js";import"./vue.esm-bundler-BvEW-W-m.js";const p={title:"Visual/MbInputDropdown",tags:["autodocs"],render:()=>({components:{MbInputDropdown:o},template:`
      <section data-visual-target class="mbvidd-root" aria-label="MbInputDropdown visual matrix">
        <h2 class="mbvidd-title">MbInputDropdown</h2>

        <div class="mbvidd-grid">
          <MbInputDropdown label="Language" :open="true" state="focus" />
          <MbInputDropdown label="Language" :open="false" state="default" />
          <MbInputDropdown label="Language" :open="true" state="error" error-message="Error message" />
        </div>

        <style>
          .mbvidd-root {
            width: 100%;
            min-height: 100%;
            padding: 12px;
            box-sizing: border-box;
            background: var(--mb-stage-bg);
            color: var(--mb-stage-text);
            border: 1px solid var(--mb-stage-border);
            border-radius: 12px;
            font-family: var(--mb-idd-font-family);
            display: grid;
            gap: 10px;
          }

          .mbvidd-title {
            margin: 0;
            font-size: 18px;
            line-height: 24px;
          }

          .mbvidd-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            justify-items: center;
            gap: 10px;
          }
        </style>
      </section>
    `})},a={parameters:s({figmaNodeId:"21502:24879",viewport:"desktop",theme:"light",state:"matrix",variant:"all"})};var e,t,r;a.parameters={...a.parameters,docs:{...(e=a.parameters)==null?void 0:e.docs,source:{originalSource:`{
  parameters: visualParameters({
    figmaNodeId: '21502:24879',
    viewport: 'desktop',
    theme: 'light',
    state: 'matrix',
    variant: 'all'
  })
}`,...(r=(t=a.parameters)==null?void 0:t.docs)==null?void 0:r.source}}};const m=["Matrix"];export{a as Matrix,m as __namedExportsOrder,p as default};
