import{d as w,e as o,k as s,t as v,g as y,f as j,j as a,r as F,o as r,w as N}from"./vue.esm-bundler-BvEW-W-m.js";const O=["data-size","data-state","data-floating"],T=["aria-label"],A={class:"mb-fif__floating-label"},G={class:"mb-fif__floating-label-text"},J={key:0,class:"mb-fif__required"},K=["value","placeholder","disabled","aria-invalid","aria-describedby"],Q={key:0,class:"mb-fif__trailing","aria-hidden":"true"},R=["id"],U=["id"],h=w({__name:"MbFloatingInputField",props:{modelValue:{},size:{default:"lg"},state:{default:"default"},label:{default:"Label"},required:{type:Boolean,default:!1},hint:{default:"Hint text"},errorMessage:{default:"Error message"},placeholder:{default:"Placeholder"},trailingIcon:{default:"rhombus"},disabled:{type:Boolean,default:!1},ariaLabel:{default:void 0}},emits:["update:modelValue","focus","blur"],setup(e,{emit:d}){const i=e,p=d,l=a(()=>i.disabled?"disabled":i.state),I=a(()=>i.modelValue!==void 0),_=F(""),u=F(!1),B=a(()=>l.value==="disabled"),m=a(()=>l.value==="error"),D=`mb-fif-${Math.random().toString(36).slice(2,10)}`,g=a(()=>`${D}-${m.value?"error":"hint"}`),c=a(()=>I.value?i.modelValue??"":_.value),M=a(()=>l.value!=="default"?l.value:u.value?"focus":"default"),P=a(()=>u.value||l.value==="focus"||l.value==="filled"||l.value==="error"||c.value.length>0),$=a(()=>M.value==="focus"&&c.value.length===0),q=a(()=>c.value.length>0?c.value:l.value==="filled"?"Filled":"");function C(n){const t=n.target;t&&(I.value||(_.value=t.value),p("update:modelValue",t.value))}function H(n){u.value=!0,p("focus",n)}function L(n){u.value=!1,p("blur",n)}return(n,t)=>(r(),o("div",{class:"mb-fif","data-size":e.size,"data-state":M.value,"data-floating":P.value?"true":"false"},[s("label",{class:"mb-fif__control","aria-label":e.ariaLabel??e.label},[s("span",A,[s("span",G,v(e.label),1),e.required?(r(),o("span",J,"*")):y("",!0)]),s("input",{class:"mb-fif__input",value:q.value,placeholder:$.value?e.placeholder:"",disabled:B.value,"aria-invalid":m.value?"true":"false","aria-describedby":g.value,onInput:C,onFocus:H,onBlur:L},null,40,K),e.trailingIcon==="rhombus"?(r(),o("span",Q,[...t[0]||(t[0]=[s("span",{class:"mb-fif__rhombus"},null,-1)])])):y("",!0),j(n.$slots,"trailing")],8,T),m.value?(r(),o("p",{key:1,id:g.value,class:"mb-fif__error"},[t[1]||(t[1]=s("span",{class:"mb-fif__error-icon","aria-hidden":"true"},"!",-1)),s("span",null,v(e.errorMessage),1)],8,U)):(r(),o("p",{key:0,id:g.value,class:"mb-fif__hint"},v(e.hint),9,R))],8,O))}}),W=["default","hover","focus","filled","disabled","error"],Y={title:"Components/MbFloatingInputField",component:h,tags:["autodocs"],args:{size:"lg",state:"default",label:"Label",required:!0,hint:"Hint text",errorMessage:"Error message",placeholder:"Placeholder",trailingIcon:"rhombus"},argTypes:{size:{control:"inline-radio",options:["lg","md","sm"]},state:{control:"inline-radio",options:W},trailingIcon:{control:"inline-radio",options:["rhombus","none"]}},render:e=>({components:{MbFloatingInputField:h},setup(){const d=F(e.modelValue??"");return N(()=>e.modelValue,i=>{d.value=i??""}),{args:e,value:d}},template:`
      <div style="display:grid;gap:16px;align-items:start;justify-items:start;padding:24px;">
        <MbFloatingInputField v-bind="args" :model-value="value" @update:modelValue="value = $event" />
      </div>
    `})},f={},b={render:()=>({components:{MbFloatingInputField:h},template:`
      <div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;padding:24px;">
        <MbFloatingInputField label="Default" state="default" />
        <MbFloatingInputField label="Hover" state="hover" />
        <MbFloatingInputField label="Focus" state="focus" />
        <MbFloatingInputField label="Filled" state="filled" />
        <MbFloatingInputField label="Disabled" state="disabled" />
        <MbFloatingInputField label="Error" state="error" />
      </div>
    `})};var x,V,S;f.parameters={...f.parameters,docs:{...(x=f.parameters)==null?void 0:x.docs,source:{originalSource:"{}",...(S=(V=f.parameters)==null?void 0:V.docs)==null?void 0:S.source}}};var k,E,z;b.parameters={...b.parameters,docs:{...(k=b.parameters)==null?void 0:k.docs,source:{originalSource:`{
  render: () => ({
    components: {
      MbFloatingInputField
    },
    template: \`
      <div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;padding:24px;">
        <MbFloatingInputField label="Default" state="default" />
        <MbFloatingInputField label="Hover" state="hover" />
        <MbFloatingInputField label="Focus" state="focus" />
        <MbFloatingInputField label="Filled" state="filled" />
        <MbFloatingInputField label="Disabled" state="disabled" />
        <MbFloatingInputField label="Error" state="error" />
      </div>
    \`
  })
}`,...(z=(E=b.parameters)==null?void 0:E.docs)==null?void 0:z.source}}};const Z=["Playground","States"];export{f as Playground,b as States,Z as __namedExportsOrder,Y as default};
